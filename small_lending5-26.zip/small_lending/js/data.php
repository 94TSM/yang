<?php
/**
 * @Author: anchen
 * @Date:   2017-05-06 14:38:33
 * @Last Modified by:   anchen
 * @Last Modified time: 2017-05-06 17:03:23
 */
$prize_arr = array( 
    '0' => array('id'=>1,'min'=>137,'max'=>178,'prize'=>'恭喜你，中得一等奖，还要再来一次吗？','v'=>1), 
    '1' => array('id'=>2,'min'=>227,'max'=>268,'prize'=>'恭喜你，中得二等奖，还要再来一次吗？','v'=>3), 
    '2' => array('id'=>3,'min'=>2,'max'=>43,'prize'=>'恭喜你，中得三等奖，还要再来一次吗？','v'=>5), 
    '3' => array('id'=>4,'min'=>array(47,92,182,272,317), 
'max'=>array(88,133,223,313,358),'prize'=>'很遗憾，差一点，再接再厉','v'=>1000) 
); 
function getRand($proArr) { 
    $result = ''; 
 
    //概率数组的总概率精度 
    $proSum = array_sum($proArr); 
 
    //概率数组循环 
    foreach ($proArr as $key => $proCur) { 
        $randNum = mt_rand(1, $proSum); 
        if ($randNum <= $proCur) { 
            $result = $key; 
            break; 
        } else { 
            $proSum -= $proCur; 
        } 
    } 
    unset ($proArr); 
 
    return $result; 
} 
foreach ($prize_arr as $key => $val) { 
    $arr[$val['id']] = $val['v']; 
} 
 
$rid = getRand($arr); //根据概率获取奖项id 
 
$res = $prize_arr[$rid-1]; //中奖项 
$min = $res['min']; 
$max = $res['max']; 
if($res['id']==4){ //七等奖 
    $i = mt_rand(0,5); 
    $result['angle'] = mt_rand($min[$i],$max[$i]); 
}else{ 
    $result['angle'] = mt_rand($min,$max); //随机生成一个角度 
} 
$result['prize'] = $res['prize']; 
 
echo json_encode($result); 
?>