/* 
* @Author: anchen
* @Date:   2017-05-24 15:08:14
* @Last Modified by:   anchen
* @Last Modified time: 2017-05-26 18:29:44
*/

    function geturl(){
        var x="http://120.55.114.43:8087/flow/";
        //$("#geturl").val(x);
        return x;
    }
    function getpcId(){
        var PcId=window.location.href;
        var num=PcId.search(/productId=/)+10;
        PcId=PcId.slice(num);

        return PcId;
    }