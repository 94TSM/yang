$(function(){
  $(".mask,.zj").hide();
   $.ajax({
		type : 'POST',
		url : 'http://192.168.1.105/flow/getAwardHtml.do?userId=2700020170107047571',
		dataType : 'json',
        success: function(data,status){
          if(!data.bizSucc ){
            return false;
          }
        var b=data.obj;
        var avaiable=b.avaiable;
        $("#integral").html(avaiable);

		}
	});
})
function unfold(){
   $(".mask,.zj").hide();
}
