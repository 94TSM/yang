document.writeln("<footer>");
document.writeln("	      <li><a href=\'index.html\'><img src=\'../images/footer_1.png\'><p>借呗</p></a></li>");
document.writeln("          <li><a href=\'makemoney.html\'><img src=\'../images/footer_2.png\'><p>赚呗</p></a></li>");
document.writeln("           <li><a href=\'find.html\'><img src=\'../images/footer_3.png\'><p>发现</p></a></li>");
document.writeln("           <li><a href=\'mine.html\'><img src=\'../images/footer_4.png\'><p>我的</p></a></li>");
document.writeln("		</footer>");