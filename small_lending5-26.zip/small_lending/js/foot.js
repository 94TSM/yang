/* 
* @Author: anchen
* @Date:   2017-05-09 22:50:14
* @Last Modified by:   anchen
* @Last Modified time: 2017-05-09 22:52:47
*/


    document.writeln("<footer>");
document.writeln("        <li><a href=\'products.html\'><img src=\'../images/jiebei.png\'><p>借呗</p></a></li>");
document.writeln("          <li><a href=\'makemoney.html\'><img src=\'../images/zhuanbai.png\'><p>赚呗</p></a></li>");
document.writeln("           <li><a href=\'find.html\'><img src=\'../images/faxian.png\'><p>发现</p></a></li>");
document.writeln("           <li><a href=\'mine.html\'><img src=\'../images/wode.png\'><p>我的</p></a></li>");
document.writeln("      </footer>");
