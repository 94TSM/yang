$.cookie("userId","2700020170107047571");
/*  function ungball(){
		$(".mask,.package").hide();
	}*/
  function linkSever(){
      var userId=$.cookie('userId');
      var url="http://192.168.1.105/flow/signEntrance.do?userId="+userId;
      $.ajax({
         type: "POST",
         url: url,
         dataType: "json",
         success: function(data,status){
            if(!data.bizSucc ){
               return false;
            }
            //获取用户登录
            var login=data.login;
            //获取当前签到多少天
            var continuousDay=data.continuousDay;
            //获取当天获得分数
            var todayPoint=data.todayPoint;
            //获取用户签到
            var repeatSign=data.repeatSign;
            //获取已签到的日期
	        var dayMap=data.dayMap;
	        var days = $("#js-qiandao-list li");
	        var count = 1;
	        for(var i =0;i<days.length;i++){
	            if(count == 1 && $(days[i]).hasClass("date1")){
	                if(dayMap[count] == true){
	                    $(days[i]).addClass("qiandao");
	                }else{
	                    $(days[i]).removeClass("qiandao");
	                }
	                count ++;
	            }else if(count > 1){

	                if(dayMap[count] == true){
	                    $(days[i]).addClass("qiandao");
	                }else{
	                    $(days[i]).removeClass("qiandao");
	                }
	                count ++;
	            }
	        }
	        //确定签到
            $("#js-just-qiandao").addClass('actived');
            //重复签到则不弹出窗
            if (!data.repeatSign) {
                //弹出窗
                $("#closegb").fadeIn();
            } 
            if(!login){
            	alert("请您先去登录!");
            	return;
            }else{
            	if(repeatSign){
            		//alert("您已经签到")
            	}else{
		            $("#number").html(continuousDay); 
		            $("#integral").html(todayPoint);
            	}
            }
         }
      });
    }
    $(document).ready(function(){
      linkSever();
    });

